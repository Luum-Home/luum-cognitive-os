# Full Git Stash Recovery — 2026-05-15

- Stashes exported: 37
- Tracked records: 367
- Untracked records: 635
- Unique file versions: 264
- Restored to original paths because missing: 95

## Restored original paths

| Path | Source | Bytes | SHA-256 |
|---|---|---:|---|
| `docs/05-Methodology/root/eas-test-marker.md` | stash-17 | 6 | `5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/README.md` | stash-17 | 6576 | `1a3163b766e027cfcb4557c8d9172091d0ecc5aa9848ecd5de27b1ce7e8a51d2` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-00/docs/05-Methodology/root/eas-test-marker.md` | stash-17 | 6 | `5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-00/docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.json` | stash-17 | 28319 | `0035b45685f8e72cd12c2fffe5cf46174601b8b0dbd5bb6eadda5bb250cb4781` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-00/docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.md` | stash-17 | 1812 | `4d4013e0e2ea0b39daf2456729bfb874efb81ece273866e2f78d0974473ddac1` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-00/scripts/cos-install-scope-dev-smoke` | stash-17 | 160 | `736f67f3a4207dc26b1c2820435e0c24e3c4e0bb17c3d92eaa9192f5dfa3c615` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-00/scripts/cos_install_scope_dev_smoke.py` | stash-17 | 17682 | `5d255571b1012835b87f6bff26b6fbf25f9493877acb1ddc8ac41d77e8f19931` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-00/tests/integration/test_install_scope_dev_smoke.py` | stash-17 | 1830 | `6cc6e81b55b0bf9527c502a609c0a68d0e3f37d091e721660059a452ab66846c` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/docs/00-MOCs/entrypoints/README.md` | stash-17 | 96518 | `23a9666195e64b1e7f5406bf614be5c35ee3b666b1174304dff1bba6d428d87e` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md` | stash-17 | 5049 | `c6e3843864df6c261f14921826358d1e09fc987a06cf2b167dbb3300333ae87c` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/docs/02-Decisions/adrs/INDEX.md` | stash-17 | 67714 | `5c9562d05cc889ed6a2da72e4e954a297532b35d48e73e8be7d987cb687f5263` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/docs/05-Methodology/root/executable-acceptance-specification.md` | stash-17 | 5436 | `e4b7cb116f53a9c4f12f6868458b2dc5e79a63828c32fd34a42a99a4302ccfdb` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/docs/08-References/business/master-plan-checklist.md` | stash-17 | 55563 | `5b6c1ac35d12779294561b251960b57cef70213087231bc9a342a65985e45086` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/rules/eas-evidence-artifact.md` | stash-17 | 2702 | `33aa14f4d72ae7c207d6e6ac25a63b015576c4e7cda91c61a822a9aaca78060b` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/templates/eas.md` | stash-17 | 2185 | `1db2ed6114728d5d67455dc1ee50c00df4fe937bfc4a7e4d2789dee26471a07a` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-01/tests/contracts/test_eas_docs_contract.py` | stash-17 | 1406 | `478bf355c9722193b299abca82ff080f3994e12b5dfa1c141727478689f3766f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-02/docs/05-Methodology/root/eas-test-marker.md` | stash-17 | 6 | `5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-02/docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.json` | stash-17 | 28319 | `0035b45685f8e72cd12c2fffe5cf46174601b8b0dbd5bb6eadda5bb250cb4781` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-02/docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.md` | stash-17 | 1812 | `4d4013e0e2ea0b39daf2456729bfb874efb81ece273866e2f78d0974473ddac1` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-02/scripts/cos-install-scope-dev-smoke` | stash-17 | 160 | `736f67f3a4207dc26b1c2820435e0c24e3c4e0bb17c3d92eaa9192f5dfa3c615` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-02/scripts/cos_install_scope_dev_smoke.py` | stash-17 | 17682 | `5d255571b1012835b87f6bff26b6fbf25f9493877acb1ddc8ac41d77e8f19931` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-02/tests/integration/test_install_scope_dev_smoke.py` | stash-17 | 1830 | `6cc6e81b55b0bf9527c502a609c0a68d0e3f37d091e721660059a452ab66846c` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/docs/00-MOCs/entrypoints/README.md` | stash-17 | 96518 | `23a9666195e64b1e7f5406bf614be5c35ee3b666b1174304dff1bba6d428d87e` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md` | stash-17 | 5255 | `064253e31130588c8494d620a80d7f9b3df0378e9f3e4059151f9fa2d17beb2e` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/docs/02-Decisions/adrs/INDEX.md` | stash-17 | 67714 | `5c9562d05cc889ed6a2da72e4e954a297532b35d48e73e8be7d987cb687f5263` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/docs/05-Methodology/root/executable-acceptance-specification.md` | stash-17 | 5644 | `17a7cd5a1229cac681b6468aa08f57703fe4ca7ad92a7709083ffd444098ba08` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/docs/08-References/business/master-plan-checklist.md` | stash-17 | 55563 | `5b6c1ac35d12779294561b251960b57cef70213087231bc9a342a65985e45086` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/rules/eas-evidence-artifact.md` | stash-17 | 2757 | `de092b3875a58c48d93d0d9d5dcb6d496a724f17cc46f4c37825d306cc7b6da9` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/templates/eas.md` | stash-17 | 2185 | `1db2ed6114728d5d67455dc1ee50c00df4fe937bfc4a7e4d2789dee26471a07a` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-03/tests/contracts/test_eas_docs_contract.py` | stash-17 | 1406 | `478bf355c9722193b299abca82ff080f3994e12b5dfa1c141727478689f3766f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/docs/00-MOCs/entrypoints/README.md` | stash-17 | 96786 | `6404ba6fe5f70d476ab20d1d5475a9976317b4070032ef15ba4ba4d2c3c56ffb` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md` | stash-17 | 6263 | `b33828ebf5df5392d11973d113e334ec18f40e2baacd3910775fed6210af1a3b` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/docs/05-Methodology/root/executable-acceptance-specification.md` | stash-17 | 5862 | `5c813e67a1b0566394c917d5860462e05be3a0bf64ec439ae7c313643e1b4681` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.json` | stash-17 | 28319 | `0035b45685f8e72cd12c2fffe5cf46174601b8b0dbd5bb6eadda5bb250cb4781` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.md` | stash-17 | 1812 | `4d4013e0e2ea0b39daf2456729bfb874efb81ece273866e2f78d0974473ddac1` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/docs/08-References/business/master-plan-checklist.md` | stash-17 | 55899 | `1ef53f3212deef1325bfeeac63e4552eb1eb7abd934fd73353ed3c841e63eee8` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/rules/eas-evidence-artifact.md` | stash-17 | 2757 | `de092b3875a58c48d93d0d9d5dcb6d496a724f17cc46f4c37825d306cc7b6da9` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/scripts/cos-install-scope-dev-smoke` | stash-17 | 160 | `736f67f3a4207dc26b1c2820435e0c24e3c4e0bb17c3d92eaa9192f5dfa3c615` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/scripts/cos_install_scope_dev_smoke.py` | stash-17 | 17682 | `5d255571b1012835b87f6bff26b6fbf25f9493877acb1ddc8ac41d77e8f19931` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/templates/eas.md` | stash-17 | 2185 | `1db2ed6114728d5d67455dc1ee50c00df4fe937bfc4a7e4d2789dee26471a07a` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/tests/contracts/test_eas_docs_contract.py` | stash-17 | 1406 | `478bf355c9722193b299abca82ff080f3994e12b5dfa1c141727478689f3766f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-04/tests/integration/test_install_scope_dev_smoke.py` | stash-17 | 1830 | `6cc6e81b55b0bf9527c502a609c0a68d0e3f37d091e721660059a452ab66846c` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-05/docs/06-Daily/reports/cos-falsification-benchmark-latest.json` | stash-17 | 10739 | `49193be2f47d1840884c8b8204642c8575d3e38f08e50b5ca0468c8c0c2d484c` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-05/docs/06-Daily/reports/cos-falsification-benchmark-latest.md` | stash-17 | 1572 | `625e5dc8396e5f20c647a91fd962535fe9745dcd7714e421eb9b6e79eaff9a6c` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-05/scripts/cos-falsification-benchmark` | stash-17 | 177 | `21efc65a01d34fdae6489dc638fd779220b85333a4b7c859a96c28f118dd27cc` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-05/scripts/cos_falsification_benchmark.py` | stash-17 | 7957 | `640ba921ad173b4f7e3c372f84680445ad1014a724b09a4a1af309b9063a5478` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-06/docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md` | stash-17 | 1400 | `524c30f131385ce47f48947440f998cdd7cf67d04bbbb487374680c8ebd25be3` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-06/docs/08-References/business/cos-vs-ai-slop-falsification.md` | stash-17 | 1457 | `8ab040bb30e8a5cb3dd995ddbf52147fb053bce0fba7c3ab5983dcb063f63c7f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-06/docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md` | stash-17 | 714 | `38968773398003fd7e1c6c6a092494788fae2ed3acfc16fd15d84ccbc4ae08fc` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-07/docs/00-MOCs/entrypoints/README.md` | stash-17 | 96980 | `93628dff42f928995c859baefa78795c1b217fa27656c30e1fc71613b87a271f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-07/docs/08-References/business/master-plan-checklist.md` | stash-17 | 55785 | `e447c8fca744c599bfd5b6e98286711b4d3d5184b7c688d2b7761d52949956eb` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-08/docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md` | stash-17 | 2291 | `22bad10386ddaeca2a02b4ab9803bdec27f22f048d4e4d52c61bd982f9e52be5` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-08/docs/08-References/business/cos-vs-ai-slop-falsification.md` | stash-17 | 2793 | `29f5d5b0ca50f00851c2a92b81985108de7d2a044adfb461ddd22affb3060e3b` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-08/docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md` | stash-17 | 1900 | `28d0c70736161d1c5a7f6a01ba4910fa2e243f409b0f2d9b10843d2b3ed0c243` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-09/docs/06-Daily/reports/cos-falsification-benchmark-latest.json` | stash-17 | 13542 | `9e30fd2c3eba6c6bfb428a876e7584a79507a2e8abbf99918555f5abc7fe9a5f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-09/docs/06-Daily/reports/cos-falsification-benchmark-latest.md` | stash-17 | 3200 | `0e644f6b79dae96a90e9029246b4b44439d3facf8dfbdc79dddcb1ee185ac849` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-09/scripts/cos-falsification-benchmark` | stash-17 | 177 | `21efc65a01d34fdae6489dc638fd779220b85333a4b7c859a96c28f118dd27cc` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-09/scripts/cos_falsification_benchmark.py` | stash-17 | 15445 | `34d314b02b2bb1690cdc08f2e3ccf73ab50703bff53aa9c30171d38fad4e7c70` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/00-MOCs/entrypoints/README.md` | stash-17 | 96944 | `35026050dad0b482a3d5092546894e297bb257f072f7e0050631d325af2e72ef` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md` | stash-17 | 2159 | `2eb3125d512763d07b791b251a9572ef9b2f6ba088f99a7264532b16c9a1ea17` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/02-Decisions/adrs/INDEX.md` | stash-17 | 67649 | `d40e92357f3285ea919225044b0ff4eda79e8dfaaca6cba45284b7b74eb58642` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.json` | stash-17 | 5886 | `b5df96c84eff485082a69ce351aea390221aef23244b9d02de0a9e0e4561c5b0` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.md` | stash-17 | 1187 | `c87496b6a60a8e04af5ccaea52c9390a8dabceaa46689663086ef077e688a25d` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/08-References/business/cos-vs-ai-slop-falsification.md` | stash-17 | 1612 | `97a6e1ebc17ae0de695559f701f793175949f5a07ab0f80f5ff7b2fd91eff829` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/08-References/business/master-plan-checklist.md` | stash-17 | 55824 | `3ec4ba9e161363d9675595287a688dd56fc091f9407b99f8f5d6e3bbc88024a2` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md` | stash-17 | 1291 | `6728e479f8ed05b4fc229db2cc36c5ad42af1c343c054cd2c546d1bf22d38266` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/scripts/cos-vs-ai-slop-two-repo-smoke` | stash-17 | 179 | `455ecfc329114b11efa6f51683be9a44686f40ac25941d2d84d638bcc011c052` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-10/scripts/cos_vs_ai_slop_two_repo_smoke.py` | stash-17 | 10578 | `791e7cc2feafd2442d7912b1dff3702129c9db72fd9b71dc5349761ad3b5abfd` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-11/docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.json` | stash-17 | 6808 | `7e3027025396ffcee75af1459c983f1bc1fc830c3e46e9e590129f92a9c81886` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-11/docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.md` | stash-17 | 1784 | `cf713bcdb479f64b0f58a8973705c2d270d59c9f57287119288561d9c86a69ec` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-11/manifests/primitive-lifecycle.yaml` | stash-17 | 673354 | `7efaec890c39a31808d80b72dea34c1efe10364f776f214dfd4826998ff6d809` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-11/scripts/cos-vs-ai-slop-two-repo-smoke` | stash-17 | 179 | `455ecfc329114b11efa6f51683be9a44686f40ac25941d2d84d638bcc011c052` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-11/scripts/cos_vs_ai_slop_two_repo_smoke.py` | stash-17 | 12456 | `8ef1f565bbcb5515b44facb3889967fa0c88bddaf20c13094680785b621b21b8` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/00-MOCs/entrypoints/README.md` | stash-17 | 96854 | `9a9a6ce84856eb466066fb9d128b15cbfa6704b406f9c7429d222100db9d64b7` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md` | stash-17 | 5068 | `761c6c20635e2d908116650c226b59167551afa45231373d9d0dee65ef6d59a0` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/02-Decisions/adrs/INDEX.md` | stash-17 | 67649 | `d40e92357f3285ea919225044b0ff4eda79e8dfaaca6cba45284b7b74eb58642` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/06-Daily/reports/manifest-tier-warning-backlog-2026-05-15.md` | stash-17 | 3221 | `13010d36165ffa9dc8e58036d46dbafead771016103344fe6266bc23a4e99429` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/06-Daily/reports/primitive-scope-unknown-triage-latest.md` | stash-17 | 27403 | `e8e347f6aac40481631a4a515b6456f0cc0369a580482f90240ad1c56f48d582` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/08-References/business/cos-vs-ai-slop-falsification.md` | stash-17 | 5919 | `ebecc006339d882fea1394c467c7a9d14e1a6f57b958b100b84843a4fac4b9ff` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/08-References/business/master-plan-checklist.md` | stash-17 | 55633 | `876682ae2b25e39ca5708a2252cf00135fc28f3eb17587c78d9b9da89ca1a0a9` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md` | stash-17 | 3653 | `f7072a75d85030477bb81430f6c1c587030b1726c4b5ff72bbbe2063a7968e42` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/files/stash-12/manifests/primitive-lifecycle.yaml` | stash-17 | 671646 | `60f6cd7b84e692e0f9b0769383ae3752fa30f378ceec97a959bb312b94c904c0` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-00.patch` | stash-17 | 52229 | `2bd97df39cc8d22b74d133c74668782d001986855150d8a2826240f706deb935` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-01.patch` | stash-17 | 23713 | `95cb5176668a1be46d934964f6d236fcd762b0a399f8c0db976a1a909c72f8d1` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-02.patch` | stash-17 | 52229 | `2bd97df39cc8d22b74d133c74668782d001986855150d8a2826240f706deb935` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-03.patch` | stash-17 | 24257 | `622b103ef1f8eada99c037d92c54afb1303aa6475f5bb0e6485ed0cf4e6bec2a` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-04.patch` | stash-17 | 76554 | `d2f43e1affe6234b0d0edbd1f47ea7a43f6c7bc6ebe955d7fb7e31c8e825b5c2` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-05.patch` | stash-17 | 21888 | `e51eb7591e7b32378b32e9496c843a76cb9dd46e204868b5747eb090bec4370b` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-06.patch` | stash-17 | 4538 | `cd8d653c0d6cf28ba6f409e8556d27511f28bf22cf5be4723e0ed37ebee16216` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-07.patch` | stash-17 | 4293 | `5d0993ae14785b9a7cbf1569cd5209697f7371d4e10bb8ffd4f41c631ce2125f` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-08.patch` | stash-17 | 8043 | `5ce789ea4cbc63179230a1a2516583704544031745d90688970838ca49d457f9` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-09.patch` | stash-17 | 34074 | `5f32808eb9b892f849f3979e33187f14a72108ec0ee5272bda468b0d9ccac339` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-10.patch` | stash-17 | 31394 | `affd4702d2121e864c78bb1b9cdb3fbe6045889f204c9f5aa87a7edeb2280c29` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-11.patch` | stash-17 | 68875 | `ccbbad8dbe791553a413aff922caefebcded1abe48c20e064c2270d10496af41` |
| `docs/06-Daily/reports/stash-recovery-2026-05-15/patches/stash-12.patch` | stash-17 | 101342 | `1d6e4a9a944ebfdd9a201dbea62a8eac297bfd7f4b04da3bdc469e951370e95f` |

## Stash inventory

| Label | Ref | Hash | Tracked | Untracked | Subject |
|---|---|---|---:|---:|---|
| stash-00 | `stash@{0}` | `32b778f83903` | 6 | 1 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-detractor-leftovers-after-hook-scope-fix-2026-05-15 |
| stash-01 | `stash@{1}` | `2eb5283d9fd5` | 7 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-detractor-leftovers-before-hook-scope-commit-2026-05-15 |
| stash-02 | `stash@{2}` | `9c38ee11c71d` | 5 | 1 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-detractor-leftovers-before-install-hook-fix-2026-05-15 |
| stash-03 | `stash@{3}` | `597c81b92789` | 5 | 1 | On codex/harness-normalized-primitive-closure: codex-isolate-detractor-adr-leftovers-after-install-scope-adr-2026-05-15 |
| stash-04 | `stash@{4}` | `c82aecc91e71` | 4 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-leftovers-before-install-scope-adr-commit-2-2026-05-15 |
| stash-05 | `stash@{5}` | `77522dc92a58` | 6 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-leftovers-before-install-scope-adr-commit-2026-05-15 |
| stash-06 | `stash@{6}` | `a878169d1474` | 10 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-leftovers-before-install-scope-adr-2026-05-15 |
| stash-07 | `stash@{7}` | `133b9122fdf5` | 7 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-eas-leftovers-after-agent-runtime-scope-2026-05-15 |
| stash-08 | `stash@{8}` | `862e90f99a3e` | 2 | 1 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-doc-leftovers-before-memory-agent-scope-2026-05-15 |
| stash-09 | `stash@{9}` | `0d04553d14ba` | 2 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-leftovers-before-doctor-scope-commit-2026-05-15 |
| stash-10 | `stash@{10}` | `38a10d8bc7a2` | 2 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-leftovers-before-primitive-reclass-continue-2026-05-15 |
| stash-11 | `stash@{11}` | `314ae985452a` | 2 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-reports-before-primitive-reclass-2026-05-15 |
| stash-12 | `stash@{12}` | `5b4f236f647f` | 2 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-leftovers-before-primitive-reclass-2026-05-15 |
| stash-13 | `stash@{13}` | `5f556c9cc4d3` | 1 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-enhancement-after-stash-smoke-2026-05-15 |
| stash-14 | `stash@{14}` | `e9b0ca00c1f1` | 1 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-test-enhancement-before-stash-quarantine-2026-05-15 |
| stash-15 | `stash@{15}` | `630604160688` | 1 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-install-scope-smoke-enhancement-before-stash-quarantine-2026-05-15 |
| stash-16 | `stash@{16}` | `a3f5b5bf939f` | 2 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-auto-checkpoint-copy-only-before-eas-2026-05-15 |
| stash-17 | `stash@{17}` | `5f447509c4ee` | 128 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-unrelated-eas-after-script-scope-2026-05-15 |
| stash-18 | `stash@{18}` | `3663965667f9` | 21 | 124 | On codex/harness-normalized-primitive-closure: codex-isolate-unrelated-eas-before-script-scope-keep-index-2026-05-15 |
| stash-19 | `stash@{19}` | `08f606836c24` | 125 | 0 | On codex/harness-normalized-primitive-closure: codex-isolate-unrelated-eas-before-script-scope-2026-05-15 |
| stash-20 | `stash@{20}` | `3907b10c4ed0` | 2 | 121 | On codex/harness-normalized-primitive-closure: preserve unrelated resurfaced artifacts before script contradictions continue |
| stash-21 | `stash@{21}` | `712d30c74380` | 6 | 116 | On codex/harness-normalized-primitive-closure: preserve unrelated artifacts resurfaced during skill commit hook |
| stash-22 | `stash@{22}` | `5170d8093e4e` | 0 | 116 | On codex/harness-normalized-primitive-closure: preserve unrelated recovered stash artifacts before skills scope batch |
| stash-23 | `stash@{23}` | `9caa91c45b96` | 0 | 94 | On codex/harness-normalized-primitive-closure: preserve unrelated stash recovery report after hook taxonomy closure |
| stash-24 | `stash@{24}` | `5a7b699a105f` | 0 | 6 | On codex/harness-normalized-primitive-closure: preserve unrelated install smoke resurfaced during agent hook batch |
| stash-25 | `stash@{25}` | `457fd410cb9f` | 3 | 5 | On codex/harness-normalized-primitive-closure: preserve unrelated EAS docs resurfaced during agent hook batch |
| stash-26 | `stash@{26}` | `affa55e638a9` | 0 | 6 | On codex/harness-normalized-primitive-closure: preserve unrelated install-scope smoke resurfaced during hook contradiction closure |
| stash-27 | `stash@{27}` | `8779201d58d7` | 3 | 5 | On codex/harness-normalized-primitive-closure: preserve unrelated EAS docs resurfaced during hook contradictions |
| stash-28 | `stash@{28}` | `f20e094a96ab` | 2 | 10 | On codex/harness-normalized-primitive-closure: preserve unrelated EAS/install-scope work before skill scope contract fix |
| stash-29 | `stash@{29}` | `c92b00228146` | 0 | 4 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification benchmark resurfaced before semantic hook contradictions |
| stash-30 | `stash@{30}` | `05a563e037e2` | 0 | 3 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification docs resurfaced after classifier commit |
| stash-31 | `stash@{31}` | `2731ac7f4c7a` | 2 | 0 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification index updates before classifier robustness |
| stash-32 | `stash@{32}` | `63c3706f6e38` | 0 | 3 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification docs before classifier robustness |
| stash-33 | `stash@{33}` | `67865e0589ad` | 0 | 4 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification benchmark before classifier robustness |
| stash-34 | `stash@{34}` | `ad11f668f9ac` | 3 | 7 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification smoke work resurfaced during hook batch |
| stash-35 | `stash@{35}` | `57ba56afded6` | 1 | 4 | On codex/harness-normalized-primitive-closure: preserve unrelated falsification smoke work before hook scope batch |
| stash-36 | `stash@{36}` | `7afb1e3b80b7` | 6 | 3 | On codex/harness-normalized-primitive-closure: preserve unrelated work before scope recalibration batches |
