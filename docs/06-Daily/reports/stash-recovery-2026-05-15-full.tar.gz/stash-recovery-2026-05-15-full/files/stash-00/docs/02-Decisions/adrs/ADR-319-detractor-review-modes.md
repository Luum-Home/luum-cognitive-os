---
adr: 319
title: Detractor Review Modes for Planning and Verification
status: accepted
implementation_status: partial
date: '2026-05-15'
supersedes: []
superseded_by: null
implementation_files:
- rules/adversarial-review.md
- rules/eas-evidence-artifact.md
- docs/05-Methodology/root/executable-acceptance-specification.md
- templates/eas.md
- scripts/eas_validate.py
- skills/sdd-spec/SKILL.md
- skills/sdd-verify/SKILL.md
tier: product
classification_basis: accepted doctrine, EAS template/validator enforcement, SDD skill wiring, and adversarial-review rule updates; automatic hook enforcement is advisory and not yet mode-specific across every review surface
partial_remaining: Detractor mode is enforced for EAS artifacts, but generic code/PR/doc review surfaces still consume it as guidance through rules rather than a dedicated mode-aware runtime contract.
remaining_in_scope: true
---

# ADR-319: Detractor Review Modes for Planning and Verification

## Context

Cognitive OS already required adversarial review and EAS detractor objections, but the skeptical role was underspecified. It could catch zero-finding reviews, yet it did not name when the agent should challenge consensus, run a pre-mortem, use a Black Hat risk lens, or escalate to formal red-team thinking.

The operator requested a portable primitive usable by both adopter projects and the OS itself while planning, creating documentation, implementing, and verifying work. The candidate terms were Tenth Man Rule, Devil's Advocate, Red Team, Pre-mortem, Black Hat, and AI-as-teammate Devil's Advocate.

## Decision

Adopt **Detractor** as the canonical agentic primitive slot.

The Detractor is a Tenth-Man / Devil's-Advocate-inspired reviewer that must argue that the EAS, plan, implementation, or final verification will fail before the system claims confidence.

The named techniques are selectable modes, not separate required primitives:

| Mode | Use when | Required shape |
|---|---|---|
| Tenth Man Rule | Consensus is strong, premature, or suspiciously cheap. | Assume the consensus is wrong and build the contrary thesis. |
| Devil's Advocate | Medium or larger plans need skeptical questioning. | Ask for alternatives, drawbacks, evidence, and assumptions. |
| Pre-mortem | Rollouts, migrations, releases, or architecture decisions could fail after approval. | Narrate the future failure and identify likely causes. |
| Black Hat | A Six Thinking Hats style risk pass is useful. | Identify risks, difficulties, and why the proposal may not work. |
| Red Team | Security, abuse, prompt-injection, or adversarial misuse is in scope. | Attack paths, exploit hypotheses, and mitigations. |

Multiple modes may be selected for the same work item. The default lightweight mode for EAS is Devil's Advocate; use Tenth Man Rule when there is visible convergence, Pre-mortem for rollout/release risk, Black Hat for structured risk review, and Red Team for adversarial/security domains.

## Integration Points

- `rules/adversarial-review.md` defines the general review protocol and the Detractor mode taxonomy.
- `rules/eas-evidence-artifact.md` routes EAS and named detractor-mode requests.
- `templates/eas.md` includes a required `Detractor Mode` section.
- `scripts/eas_validate.py` fails EAS artifacts that omit a valid mode.
- `skills/sdd-spec/SKILL.md` creates EAS when the user asks for any named mode or a required contrary thesis.
- `skills/sdd-verify/SKILL.md` verifies the selected mode, objections, evidence, and residual risk.

## Relationship to ADR-317

ADR-317 owns EAS as the evidence artifact. This ADR owns the broader Detractor role and mode taxonomy. EAS is the first enforceable implementation surface for the role.

## Consequences

Positive: skeptical review becomes explicit, portable, and selectable by risk instead of relying on generic "be adversarial" language. EAS evidence improves because objections must name the mode, contrary thesis, and disconfirming evidence.

Tradeoffs: this adds one required EAS section and slightly more ceremony for significant work. Generic PR/code/doc review remains mode-aware by doctrine but not yet validated by a dedicated mode parser.

## Reference Basis

- Brookings, `Lessons from Israel's Intelligence Reforms`, for Israeli intelligence reforms and devil's-advocate structures.
- CIA Center for the Study of Intelligence, `Instituting Devil's Advocacy in IC Analysis after the Arab-Israeli War of October 1973`, for formal alternative analysis, red cells, and devil's advocacy.
- de Bono Group, `Six Thinking Hats`, for the Black Hat risk lens.
- Mollick & Mollick, `Assigning AI: Seven Approaches for Students, with Prompts`, and Microsoft's `prompts-for-edu` Devil's Advocate prompt, for the AI-teammate framing.

## Verification

```bash
.venv/bin/python -m pytest tests/contracts/test_eas_docs_contract.py tests/contracts/test_eas_manifest_and_sdd_wiring.py tests/unit/test_eas_validate.py -q
bash tests/unit/test_adversarial_review_gate.sh
.venv/bin/python -m pytest tests/red_team/portability/test_eas.py tests/red_team/portability/test_adversarial-review.py -q
```
