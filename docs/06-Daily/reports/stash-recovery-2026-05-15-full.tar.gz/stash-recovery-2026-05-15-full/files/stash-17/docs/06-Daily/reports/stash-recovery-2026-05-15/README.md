# Stash recovery inventory — 2026-05-15

Recovered from branch: codex/harness-normalized-primitive-closure
Generated: 2026-05-15T13:17:33Z

This directory is a non-destructive recovery of all current stashes.

## stash-00

```
stash@{Fri May 15 10:15:02 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated install smoke resurfaced during agent hook batch
A	docs/05-Methodology/root/eas-test-marker.md
A	docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.json
A	docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.md
A	scripts/cos-install-scope-dev-smoke
A	scripts/cos_install_scope_dev_smoke.py
A	tests/integration/test_install_scope_dev_smoke.py
```

## stash-01

```
stash@{Fri May 15 10:14:47 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated EAS docs resurfaced during agent hook batch
M	docs/00-MOCs/entrypoints/README.md
A	docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md
M	docs/02-Decisions/adrs/INDEX.md
A	docs/05-Methodology/root/executable-acceptance-specification.md
M	docs/08-References/business/master-plan-checklist.md
A	rules/eas-evidence-artifact.md
A	templates/eas.md
A	tests/contracts/test_eas_docs_contract.py
```

## stash-02

```
stash@{Fri May 15 10:11:24 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated install-scope smoke resurfaced during hook contradiction closure
A	docs/05-Methodology/root/eas-test-marker.md
A	docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.json
A	docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.md
A	scripts/cos-install-scope-dev-smoke
A	scripts/cos_install_scope_dev_smoke.py
A	tests/integration/test_install_scope_dev_smoke.py
```

## stash-03

```
stash@{Fri May 15 10:10:42 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated EAS docs resurfaced during hook contradictions
M	docs/00-MOCs/entrypoints/README.md
A	docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md
M	docs/02-Decisions/adrs/INDEX.md
A	docs/05-Methodology/root/executable-acceptance-specification.md
M	docs/08-References/business/master-plan-checklist.md
A	rules/eas-evidence-artifact.md
A	templates/eas.md
A	tests/contracts/test_eas_docs_contract.py
```

## stash-04

```
stash@{Fri May 15 10:07:27 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated EAS/install-scope work before skill scope contract fix
M	docs/00-MOCs/entrypoints/README.md
A	docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md
A	docs/05-Methodology/root/executable-acceptance-specification.md
A	docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.json
A	docs/06-Daily/reports/cos-install-scope-dev-smoke-latest.md
M	docs/08-References/business/master-plan-checklist.md
A	rules/eas-evidence-artifact.md
A	scripts/cos-install-scope-dev-smoke
A	scripts/cos_install_scope_dev_smoke.py
A	templates/eas.md
A	tests/contracts/test_eas_docs_contract.py
A	tests/integration/test_install_scope_dev_smoke.py
```

## stash-05

```
stash@{Fri May 15 09:55:09 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification benchmark resurfaced before semantic hook contradictions
A	docs/06-Daily/reports/cos-falsification-benchmark-latest.json
A	docs/06-Daily/reports/cos-falsification-benchmark-latest.md
A	scripts/cos-falsification-benchmark
A	scripts/cos_falsification_benchmark.py
```

## stash-06

```
stash@{Fri May 15 09:45:28 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification docs resurfaced after classifier commit
A	docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md
A	docs/08-References/business/cos-vs-ai-slop-falsification.md
A	docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md
```

## stash-07

```
stash@{Fri May 15 09:44:43 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification index updates before classifier robustness
M	docs/00-MOCs/entrypoints/README.md
M	docs/08-References/business/master-plan-checklist.md
```

## stash-08

```
stash@{Fri May 15 09:44:19 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification docs before classifier robustness
A	docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md
A	docs/08-References/business/cos-vs-ai-slop-falsification.md
A	docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md
```

## stash-09

```
stash@{Fri May 15 09:44:08 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification benchmark before classifier robustness
A	docs/06-Daily/reports/cos-falsification-benchmark-latest.json
A	docs/06-Daily/reports/cos-falsification-benchmark-latest.md
A	scripts/cos-falsification-benchmark
A	scripts/cos_falsification_benchmark.py
```

## stash-10

```
stash@{Fri May 15 09:13:17 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification smoke work resurfaced during hook batch
M	docs/00-MOCs/entrypoints/README.md
A	docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md
M	docs/02-Decisions/adrs/INDEX.md
A	docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.json
A	docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.md
A	docs/08-References/business/cos-vs-ai-slop-falsification.md
M	docs/08-References/business/master-plan-checklist.md
A	docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md
A	scripts/cos-vs-ai-slop-two-repo-smoke
A	scripts/cos_vs_ai_slop_two_repo_smoke.py
```

## stash-11

```
stash@{Fri May 15 09:09:12 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated falsification smoke work before hook scope batch
A	docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.json
A	docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.md
M	manifests/primitive-lifecycle.yaml
A	scripts/cos-vs-ai-slop-two-repo-smoke
A	scripts/cos_vs_ai_slop_two_repo_smoke.py
```

## stash-12

```
stash@{Fri May 15 09:05:23 2026}: On codex/harness-normalized-primitive-closure: preserve unrelated work before scope recalibration batches
M	docs/00-MOCs/entrypoints/README.md
A	docs/02-Decisions/adrs/ADR-317-cos-falsification-before-promotion.md
M	docs/02-Decisions/adrs/INDEX.md
M	docs/06-Daily/reports/manifest-tier-warning-backlog-2026-05-15.md
M	docs/06-Daily/reports/primitive-scope-unknown-triage-latest.md
A	docs/08-References/business/cos-vs-ai-slop-falsification.md
M	docs/08-References/business/master-plan-checklist.md
A	docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md
M	manifests/primitive-lifecycle.yaml
```

