---
adr: 317
title: Executable Acceptance Specification (EAS) Evidence Artifact
status: accepted
implementation_status: partial
date: '2026-05-15'
supersedes: []
superseded_by: null
implementation_files:
- docs/05-Methodology/root/executable-acceptance-specification.md
- templates/eas.md
- rules/eas-evidence-artifact.md
tier: product
classification_basis: accepted doctrine and initial documentation/template/rule surface; runtime enforcement is not yet wired
partial_remaining: EAS is documented and templated, but SDD phase skills and validators do not yet enforce the EAS schema automatically.
remaining_in_scope: true
---

# ADR-317: Executable Acceptance Specification (EAS) Evidence Artifact

## Context

Cognitive OS already has distributed evidence practices: mandatory acceptance criteria, verification commands, SDD phases, adversarial review with zero-finding halt, gap matrices in audit work, and residual-risk sections in several ADRs.

The missing doctrine is a single optional developer-facing artifact that turns intention into acceptance evidence without forcing teams to abandon their existing documentation formats.

## Decision

Adopt **Executable Acceptance Specification (EAS)** as an optional documentation artifact for significant changes.

EAS is not a replacement for SDD:

```text
SDD = workflow / process
EAS = artifact / documentation format
ATDD/TDD = execution and verification style
```

EAS must be able to represent or reference other known formats while preserving executable acceptance as the invariant. Its canonical sections are: Intent, Requirements, Non-goals, Executable acceptance criteria, Gap matrix, Adversarial personas, Detractor objection log, Verification commands, and Residual risks.

EAS is mandatory only when a caller, skill, or project policy asks for it. Otherwise it is recommended for large or critical SDD work and optional for smaller changes.

## Relationship to Existing Formats

EAS is an adapter layer, not a competing methodology.

| Existing format | EAS relationship |
|---|---|
| PRD | Product intent, users, goals, non-goals, and success measures. |
| RFC | Alternatives, tradeoffs, open questions, and proposed approach. |
| ADR | Durable decisions and consequences. |
| Gherkin | Executable behavior scenarios for ATDD. |
| OpenAPI / AsyncAPI | External API contracts and contract tests. |
| Test plan | Manual, unit, integration, contract, and regression checks. |
| Threat model | Abuse cases, security requirements, and mitigations. |
| Runbook | Rollout, rollback, observability, and operational checks. |

## Integration with SDD

Full SDD can emit and consume EAS as follows:

```text
explore -> propose -> spec/design -> EAS -> tasks -> apply -> verify -> archive
```

- `sdd-spec` may create or update EAS requirements and executable acceptance sections.
- `sdd-design` may add architecture constraints, alternatives, and risk notes referenced by EAS.
- `sdd-tasks` should derive implementation tasks from the EAS gap matrix and acceptance mapping.
- `sdd-apply` should implement against EAS acceptance rows, not only prose requirements.
- `sdd-verify` should check that every EAS requirement has evidence, every unresolved gap is explicit, and every detractor objection is either addressed or carried as residual risk.

## Adversarial Review Requirement

EAS introduces a stronger adversarial shape than generic review: adversarial personas review from distinct stakeholder lenses; a named **Detractor** argues that the implementation will fail to satisfy the artifact; objections are logged before implementation or before final verification; and every objection is resolved by evidence, converted into a task, or accepted as residual risk.

## Consequences

Positive: SDD gains a single evidence artifact that can bridge documentation, ATDD, and TDD; acceptance criteria become traceable from requirement to test/evidence; existing formats remain usable; and adversarial review becomes part of the specification, not only a late verify step.

Tradeoffs: EAS adds ceremony when used on trivial or small changes; runtime validators are not implemented yet; and existing SDD skills need a follow-up pass before they can enforce EAS automatically.

## Alternatives Considered

### Make EAS mandatory for every SDD change

Rejected. It would conflict with ADR-014 fast-path behavior and impose unnecessary ceremony on small changes.

### Use only existing PRD/RFC/ADR formats

Rejected. Existing formats are useful but do not consistently enforce executable acceptance, coverage mapping, detractor objections, and residual risk in one artifact.

### Add only more acceptance-criteria rules

Rejected. Acceptance criteria alone do not capture source documentation, non-goals, gap coverage, adversarial objections, or residual risks.

## Verification

```bash
test -f docs/05-Methodology/root/executable-acceptance-specification.md
test -f templates/eas.md
test -f rules/eas-evidence-artifact.md
.venv/bin/python -m pytest tests/contracts/test_eas_docs_contract.py -q
```
