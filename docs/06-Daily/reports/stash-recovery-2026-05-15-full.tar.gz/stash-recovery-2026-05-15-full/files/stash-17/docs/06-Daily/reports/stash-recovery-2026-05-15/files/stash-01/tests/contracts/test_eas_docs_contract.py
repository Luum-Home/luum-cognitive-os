from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
EAS_DOC = ROOT / "docs/05-Methodology/root/executable-acceptance-specification.md"
EAS_TEMPLATE = ROOT / "templates/eas.md"
EAS_RULE = ROOT / "rules/eas-evidence-artifact.md"
EAS_ADR = ROOT / "docs/02-Decisions/adrs/ADR-317-executable-acceptance-specification-eas.md"


REQUIRED_SECTIONS = [
    "Intent",
    "Requirements",
    "Non-goals",
    "Executable Acceptance Criteria",
    "Gap Matrix",
    "Adversarial Personas",
    "Detractor Objection Log",
    "Verification Commands",
    "Residual Risks",
]


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def test_eas_artifacts_exist() -> None:
    assert EAS_DOC.is_file()
    assert EAS_TEMPLATE.is_file()
    assert EAS_RULE.is_file()
    assert EAS_ADR.is_file()


def test_eas_doc_defines_required_sections() -> None:
    text = _read(EAS_DOC)
    for section in REQUIRED_SECTIONS:
        assert section in text


def test_eas_template_contains_required_sections() -> None:
    text = _read(EAS_TEMPLATE)
    for section in REQUIRED_SECTIONS:
        assert f"## {section}" in text


def test_eas_rule_points_to_template_and_sdd_integration() -> None:
    text = _read(EAS_RULE)
    assert "templates/eas.md" in text
    for phase in ["sdd-spec", "sdd-design", "sdd-tasks", "sdd-apply", "sdd-verify", "sdd-archive"]:
        assert phase in text
