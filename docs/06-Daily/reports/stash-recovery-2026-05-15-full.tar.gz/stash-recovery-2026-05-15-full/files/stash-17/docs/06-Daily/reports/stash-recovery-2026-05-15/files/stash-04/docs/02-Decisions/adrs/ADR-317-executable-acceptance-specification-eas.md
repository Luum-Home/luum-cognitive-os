---
adr: 317
title: Executable Acceptance Specification (EAS) Evidence Artifact
status: accepted
implementation_status: partial
date: '2026-05-15'
supersedes: []
superseded_by: null
implementation_files:
- docs/05-Methodology/root/executable-acceptance-specification.md
- templates/eas.md
- rules/eas-evidence-artifact.md
tier: product
classification_basis: accepted doctrine and initial documentation/template/rule surface; runtime enforcement is not yet wired
partial_remaining: EAS is documented and templated, but SDD phase skills and validators do not yet enforce the EAS schema automatically.
remaining_in_scope: true
---

# ADR-317: Executable Acceptance Specification (EAS) Evidence Artifact

## Context

Cognitive OS already has strong but distributed evidence practices:

- mandatory acceptance criteria in `rules/acceptance-criteria.md`;
- verification commands in trust reports, DoD, and staged verification;
- SDD phases for planning, implementation, and verification;
- adversarial review with zero-finding halt in `rules/adversarial-review.md`;
- gap matrices and residual-risk sections in several audits and ADRs.

The gap is that these practices are not packaged as a single optional developer-facing documentation artifact. Developers can choose PRDs, RFCs, ADRs, Gherkin scenarios, OpenAPI documents, threat models, test plans, or runbooks, but none of those formats alone guarantees that requirements map to executable evidence.

The missing doctrine is an artifact that turns intention into acceptance evidence without forcing teams to abandon their existing documentation formats.

## Decision

Adopt **Executable Acceptance Specification (EAS)** as an optional documentation artifact for significant changes.

EAS is not a replacement for SDD. It is the evidence artifact that SDD may produce, consume, and verify:

```text
SDD = workflow / process
EAS = artifact / documentation format
ATDD/TDD = execution and verification style
```

EAS must be able to represent or reference other known formats while preserving executable acceptance as the invariant. Its canonical sections are:

1. Intent
2. Requirements
3. Non-goals
4. Executable acceptance criteria
5. Gap matrix
6. Adversarial personas
7. Detractor objection log
8. Verification commands
9. Residual risks

EAS is mandatory only when a caller, skill, or project policy asks for it. Otherwise it is a recommended artifact for large or critical SDD work and optional for smaller changes.

## Relationship to Existing Formats

EAS is an adapter layer, not a competing methodology.

| Existing format | EAS relationship |
|---|---|
| PRD | Captures product intent, users, goals, non-goals, and success measures. |
| RFC | Captures alternatives, tradeoffs, open questions, and proposed approach. |
| ADR | Captures durable decisions and consequences. |
| Gherkin | Captures executable behavior scenarios for ATDD. |
| OpenAPI / AsyncAPI | Captures external API contracts and contract tests. |
| Test plan | Captures manual, unit, integration, contract, and regression checks. |
| Threat model | Captures abuse cases, security requirements, and mitigations. |
| Runbook | Captures rollout, rollback, observability, and operational checks. |

## Integration with SDD

Full SDD can emit and consume EAS as follows:

```text
explore -> propose -> spec/design -> EAS -> tasks -> apply -> verify -> archive
```

- `sdd-spec` may create or update the EAS requirements and executable acceptance sections.
- `sdd-design` may add architecture constraints, alternatives, and risk notes referenced by EAS.
- `sdd-tasks` should derive implementation tasks from the EAS gap matrix and acceptance mapping.
- `sdd-apply` should implement against EAS acceptance rows, not only prose requirements.
- `sdd-verify` should check that every EAS requirement has evidence, every unresolved gap is explicit, and every detractor objection is either addressed or carried as residual risk.

Fast-path SDD may still skip detailed spec/design/tasks phases, but it must not skip the generator/evaluator separation: implementation and verification remain separate roles.

## Adversarial Review Requirement

EAS introduces a stronger adversarial shape than the existing generic review protocol:

- **Adversarial personas** review the artifact from distinct stakeholder lenses.
- A named **Detractor** must argue that the implementation will fail to satisfy the artifact.
- The detractor's objections are logged before implementation or before final verification.
- Every objection is resolved by evidence, converted into a task, or accepted as residual risk.

This is intentionally stricter than a normal review. It prevents a rubber-stamped EAS from becoming ceremonial documentation.

## Consequences

Positive:

- SDD gains a single evidence artifact that can bridge documentation, ATDD, and TDD.
- Acceptance criteria become traceable from requirement to test/evidence.
- Existing formats remain usable because EAS can reference or embed them.
- Adversarial review becomes part of the specification, not only a late verify step.

Negative / tradeoffs:

- EAS adds ceremony when used on trivial or small changes, so it must remain optional unless risk justifies it.
- Runtime validators are not implemented yet; initial compliance is documentation- and template-driven.
- Existing SDD skills need a follow-up pass before they can enforce EAS automatically.

## Alternatives Considered

### Make EAS mandatory for every SDD change

Rejected. It would conflict with ADR-014 fast-path behavior and impose unnecessary ceremony on small changes.

### Use only existing PRD/RFC/ADR formats

Rejected. Existing formats are useful but do not consistently enforce executable acceptance, coverage mapping, detractor objections, and residual risk in one artifact.

### Add only more acceptance-criteria rules

Rejected. Acceptance criteria alone do not capture source documentation, non-goals, gap coverage, adversarial objections, or residual risks.

## Verification

Initial verification is documentation-level:

```bash
test -f docs/05-Methodology/root/executable-acceptance-specification.md
test -f templates/eas.md
test -f rules/eas-evidence-artifact.md
python3 -m pytest tests/contracts/test_eas_docs_contract.py -q
```
