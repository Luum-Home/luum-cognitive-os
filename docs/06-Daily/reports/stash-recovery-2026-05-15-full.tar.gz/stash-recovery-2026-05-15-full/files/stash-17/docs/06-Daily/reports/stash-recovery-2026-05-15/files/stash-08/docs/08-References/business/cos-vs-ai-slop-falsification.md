# Cognitive OS vs AI Slop Falsification Protocol

## Purpose

Cognitive OS must prove it improves agent-assisted engineering outcomes. More hooks, skills, rules, ADRs, and manifests are not proof by themselves.

The product question is falsifiable:

> Does COS improve work over harness-literate native agent use, or does it add ceremony?

## Comparison Groups

| Group | Mode | Meaning |
|---|---|---|
| A | Native harness baseline | Developer uses Codex/Claude/OpenCode/Goose, shell, git, tests, permissions, PI defense, and SDD directly. |
| B | Minimal COS | Same workflow plus small/default COS substrate. |
| C | Full COS | Same workflow plus broad governance mesh. |

## Product Verdict Rules

- If A wins, COS is slop or premature abstraction for that task class.
- If B wins, the product default should be minimal COS plus agentic literacy.
- If C wins, full COS is justified only for the task classes where it wins.
- If B and C tie, prefer B: the smaller default surface wins unless full mesh produces a material outcome delta.
- If results are inconclusive, keep claims advisory/lab.

## Existing Executable Benchmark

Run the deterministic no-provider benchmark:

```bash
scripts/cos-falsification-benchmark --json --write-report
```

Latest report:

- `docs/06-Daily/reports/cos-falsification-benchmark-latest.json`
- `docs/06-Daily/reports/cos-falsification-benchmark-latest.md`

Current result on 2026-05-15:

| Group | Profile | Score | Passes | Interpretation |
|---|---|---:|---:|---|
| A | native-harness | 26 | 1/5 | Baseline passes simple tests but lacks COS safety/recovery/claim gates. |
| B | minimal-cos | 46 | 5/5 | Wins the deterministic benchmark. |
| C | full-cos | 46 | 5/5 | Ties B, so it does not justify a broader default by itself. |

Product verdict: **minimal COS default** for the deterministic safety/recovery/evidence task set.

## What This Proves

The deterministic benchmark proves that COS adds measurable local outcomes for the tested task classes:

- blocks lethal-trifecta private-data exfiltration patterns;
- blocks destructive git reset before execution;
- provides status/recovery visibility;
- keeps public high-risk claims bounded by a gate;
- preserves ordinary test execution.

## What This Does Not Yet Prove

It does not prove live LLM quality, human cognitive-load reduction, or time-to-merge improvements. Those require the manual/live protocol in `docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md`.

## Slop Tripwires

- taxonomy grows faster than evidence;
- universal/autonomous/multi-IDE claims lack proof levels;
- COS hides native harness behavior developers must understand;
- gates cannot fail visibly;
- advisory reusable primitives are marketed as core;
- maintainer intuition substitutes for durable rationale.
