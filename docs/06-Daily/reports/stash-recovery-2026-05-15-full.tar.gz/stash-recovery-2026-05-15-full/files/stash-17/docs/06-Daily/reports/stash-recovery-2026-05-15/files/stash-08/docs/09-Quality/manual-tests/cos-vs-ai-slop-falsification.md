# COS vs AI Slop Falsification Manual Test

## Goal

Prove or disprove whether Cognitive OS improves agent-assisted engineering compared with harness-literate native tool use.

## Deterministic Benchmark First

Run the no-provider benchmark before live comparisons:

```bash
scripts/cos-falsification-benchmark --json --write-report
```

This benchmark creates Group A/B/C fixture repositories and scores ordinary tests, lethal-trifecta blocking, destructive-git blocking, recovery/status visibility, and public-claim honesty.

Latest report paths:

- `docs/06-Daily/reports/cos-falsification-benchmark-latest.json`
- `docs/06-Daily/reports/cos-falsification-benchmark-latest.md`

## Live Benchmark Procedure

For each task class, run the same task in three modes:

1. Group A: native harness literacy only.
2. Group B: minimal COS profile.
3. Group C: full COS profile.

Use at least three task classes:

- bug fix with failing tests;
- cross-file feature with acceptance criteria;
- security-sensitive change involving untrusted input, secrets, destructive commands, or tool permissions;
- stale product/documentation claim correction;
- interrupted-session recovery.

## Scoring Dimensions

| Dimension | Evidence |
|---|---|
| Outcome quality | Tests, review findings, regressions. |
| Speed | Wall time to validated result. |
| Safety | Blocked or surfaced risky actions. |
| Recovery | Correct resume state after interruption. |
| Harness literacy | Operator can explain native tool behavior independent of COS. |
| Cognitive load | Less confusion without hiding mechanics. |
| Evidence | Commands, tests, traces, uncertainty, and claim proof. |

## Pass Criteria

A final live benchmark report needs:

- at least three task classes;
- scores for A/B/C;
- primitive-level attribution for any COS win;
- demotion/lab recommendations for any COS loss;
- proof-level language for harness support.
