# Cognitive OS vs AI Slop Falsification Protocol

## Purpose

Cognitive OS must prove it improves agent-assisted engineering outcomes. More hooks, skills, rules, ADRs, and manifests are not proof by themselves.

## Experiment

Compare three modes on the same realistic tasks:

| Group | Mode | What it tests |
|---|---|---|
| A | Harness-literate native workflow | Codex, Claude Code, OpenCode, Goose, shell, git, tests, permissions, PI defense, and SDD without COS ceremony. |
| B | Minimal COS | A small COS slice: memory/status, claim gates, minimal hooks, SDD, and a few proven skills. |
| C | Full COS mesh | The broad governance profile. |

## Verdict Rules

- If A wins, COS is slop or premature abstraction for that task class.
- If B wins, the product default should be minimal COS plus agentic literacy.
- If C wins, the broader mesh is justified only for the task classes it beat.
- If results are close, keep claims advisory.

## Existing Smoke

Before live model comparisons, run the two-repo substrate smoke:

```bash
scripts/cos-vs-ai-slop-two-repo-smoke --json --write-report
```

This creates a vanilla repo and a COS-projected repo. It proves projection, status visibility, claim gates, and visible manifest debt. It does not prove speed, quality, or cognitive-load wins.

## Slop Tripwires

- taxonomy grows faster than evidence;
- universal/autonomous/multi-IDE claims lack proof levels;
- COS hides native harness behavior developers must understand;
- gates cannot fail visibly;
- advisory reusable primitives are marketed as core;
- maintainer intuition substitutes for durable rationale.
