# COS vs AI Slop Falsification Manual Test

## Goal

Prove or disprove whether Cognitive OS improves agent-assisted engineering compared with harness-literate native tool use.

## Existing Non-Provider Smoke

Run this before any live model benchmark:

```bash
scripts/cos-vs-ai-slop-two-repo-smoke --json --write-report
```

Latest report paths:

- `docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.json`
- `docs/06-Daily/reports/cos-vs-ai-slop-two-repo-smoke-latest.md`

## Live Benchmark Procedure

For each task class, run the same task in three modes:

1. Group A: native harness literacy only.
2. Group B: minimal COS profile.
3. Group C: full COS profile.

Score each run on:

| Dimension | Signal |
|---|---|
| Outcome quality | tests, review findings, regressions |
| Speed | time-to-validated result |
| Safety | blocked or surfaced risky actions |
| Recovery | ability to resume after interruption |
| Harness literacy | operator can explain native tool behavior |
| Cognitive load | less confusion without hiding mechanics |
| Evidence | commands, tests, traces, uncertainty |

## Pass Criteria

A final benchmark report needs at least three task classes, scores for A/B/C, primitive-level attribution for any COS win, and demotion/lab recommendations for any COS loss.
