# COS vs AI Slop Two-Repo Smoke — Latest

Generated: `2026-05-15T12:08:51+00:00`
Status: `pass`
Mode: `non-provider-two-repo-substrate-smoke`
Harness: `codex`

## What this proves

This smoke creates two equivalent fixture repositories: a vanilla baseline and a COS-projected repo. It proves local substrate, evidence gates, and visible debt handling before any live model benchmark is run.

## Probe results

| Probe | Status | Rationale |
|---|---|---|
| `vanilla_repo_unchanged` | `pass` | Baseline repo remains a clean native-harness fixture with no COS substrate. |
| `cos_projection_exists` | `pass` | COS repo has projected, inspectable core substrate and Codex hook settings. |
| `driver_boundary_visible` | `pass` | Codex projection uses Codex-specific project env instead of hidden Claude coupling. |
| `status_visible` | `pass` | COS repo can be inspected by status tooling without model calls. |
| `public_claim_gate_clean` | `pass` | Public autonomous/self-improvement claims remain bounded by evidence gate. |
| `manifest_debt_not_hidden` | `pass` | Remaining manifest-tier debt is visible as WARN rather than silently marketed as solved. |
| `benchmark_plan_available` | `pass` | Existing so-vs-vanilla benchmark plan is runnable in no-provider dry-run mode. |

## Manifest-tier debt visibility

- status: `warn`
- primitives: `660`
- findings: `673`
- warnings: `340`

## Limitations

- Does not execute live model tasks.
- Does not prove time-to-merge, defect-rate, or cognitive-load wins.
- Only proves the local substrate needed before running the A/B/C falsification benchmark.

## Next benchmark step

Run the manual A/B/C falsification benchmark for at least three task classes. This smoke only proves that the two-repo substrate and honesty gates are ready.

