#!/usr/bin/env python3
# SCOPE: os-only
"""Two-repo non-provider smoke for COS-vs-AI-slop falsification.

This is not a model-quality benchmark. It creates a vanilla fixture repository
and a COS-projected fixture repository, then checks whether the COS repo adds
inspectable safety/proof/recovery substrate without mutating the vanilla repo or
requiring live provider calls.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_JSON = ROOT / "docs" / "06-Daily" / "reports" / "cos-vs-ai-slop-two-repo-smoke-latest.json"
DEFAULT_MD = ROOT / "docs" / "06-Daily" / "reports" / "cos-vs-ai-slop-two-repo-smoke-latest.md"


def _run(cmd: list[str], cwd: Path, timeout: int = 120, env: dict[str, str] | None = None) -> dict[str, Any]:
    import os
    run_env = os.environ.copy()
    if env:
        run_env.update(env)
    proc = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=False, timeout=timeout, env=run_env)
    return {
        "cmd": cmd,
        "cwd": str(cwd),
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "stdout_tail": proc.stdout[-2000:],
        "stderr_tail": proc.stderr[-2000:],
    }


def _write_fixture(repo: Path) -> None:
    (repo / "src").mkdir(parents=True, exist_ok=True)
    (repo / "tests").mkdir(parents=True, exist_ok=True)
    (repo / "README.md").write_text(
        "# Fixture Repo\n\nSmall repo used to compare vanilla harness workflow against COS substrate.\n",
        encoding="utf-8",
    )
    (repo / "src" / "calculator.py").write_text(
        "def add(a: int, b: int) -> int:\n    return a + b\n",
        encoding="utf-8",
    )
    (repo / "tests" / "test_calculator.py").write_text(
        "from src.calculator import add\n\n\ndef test_add() -> None:\n    assert add(2, 3) == 5\n",
        encoding="utf-8",
    )


def _tree_digest(repo: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(repo.rglob("*")):
        if path.is_file():
            rel = path.relative_to(repo).as_posix()
            digest.update(rel.encode("utf-8"))
            digest.update(b"\0")
            digest.update(path.read_bytes())
            digest.update(b"\0")
    return digest.hexdigest()


def _path_exists(repo: Path, rel: str) -> bool:
    return (repo / rel).exists()


def _has_any_skill(repo: Path) -> bool:
    skills = repo / ".cognitive-os" / "skills" / "cos"
    return skills.exists() and any(skills.rglob("SKILL.md"))


def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"_error": str(exc)}


def _score_probe(pass_condition: bool, rationale: str) -> dict[str, Any]:
    return {"status": "pass" if pass_condition else "fail", "rationale": rationale}


def build_report(root: Path = ROOT, harness: str = "codex", keep: bool = False) -> dict[str, Any]:
    root = root.resolve()
    tmp_ctx = tempfile.TemporaryDirectory(prefix="cos-vs-slop-two-repo-")
    tmp = Path(tmp_ctx.name)
    vanilla = tmp / "vanilla-repo"
    cos_repo = tmp / "cos-repo"
    vanilla.mkdir()
    cos_repo.mkdir()
    _write_fixture(vanilla)
    shutil.copytree(vanilla, cos_repo, dirs_exist_ok=True)
    vanilla_before = _tree_digest(vanilla)
    cos_before = _tree_digest(cos_repo)

    install = _run([sys.executable, str(root / "scripts" / "cos_init.py"), "--default", "--harness", harness], cwd=cos_repo)
    status = _run(["bash", str(root / "scripts" / "cos-status.sh"), "--json"], cwd=cos_repo, env={"COGNITIVE_OS_PROJECT_DIR": str(cos_repo)})
    claim_gate = _run([str(root / "scripts" / "cos-public-claim-gate"), "--json"], cwd=root)
    manifest_tier = _run([str(root / "scripts" / "cos-manifest-tier-claim-audit"), "--json"], cwd=root)
    benchmark_plan = _run([sys.executable, str(root / "scripts" / "so_vs_vanilla_benchmark.py"), "--dry-run"], cwd=root)

    install_meta = _read_json(cos_repo / ".cognitive-os" / "install-meta.json")
    status_json = _read_json_from_output(status.get("stdout", ""))
    claim_json = _read_json_from_output(claim_gate.get("stdout", ""))
    tier_json = _read_json_from_output(manifest_tier.get("stdout", ""))

    vanilla_after = _tree_digest(vanilla)
    cos_after = _tree_digest(cos_repo)
    hooks_json = cos_repo / ".codex" / "hooks.json"
    hooks_text = hooks_json.read_text(encoding="utf-8") if hooks_json.exists() else ""

    probes = {
        "vanilla_repo_unchanged": _score_probe(
            vanilla_before == vanilla_after and not _path_exists(vanilla, ".cognitive-os"),
            "Baseline repo remains a clean native-harness fixture with no COS substrate.",
        ),
        "cos_projection_exists": _score_probe(
            install["returncode"] == 0
            and _path_exists(cos_repo, ".cognitive-os")
            and _path_exists(cos_repo, ".codex/hooks.json")
            and _path_exists(cos_repo, ".cognitive-os/hooks/cos/session-init.sh")
            and _path_exists(cos_repo, ".cognitive-os/rules/cos/RULES-COMPACT.md")
            and _has_any_skill(cos_repo),
            "COS repo has projected, inspectable core substrate and Codex hook settings.",
        ),
        "driver_boundary_visible": _score_probe(
            "CODEX_PROJECT_DIR" in hooks_text and "CLAUDE_PROJECT_DIR" not in hooks_text,
            "Codex projection uses Codex-specific project env instead of hidden Claude coupling.",
        ),
        "status_visible": _score_probe(
            status["returncode"] == 0 and status_json.get("health") is not None,
            "COS repo can be inspected by status tooling without model calls.",
        ),
        "public_claim_gate_clean": _score_probe(
            claim_gate["returncode"] == 0 and claim_json.get("status") == "pass",
            "Public autonomous/self-improvement claims remain bounded by evidence gate.",
        ),
        "manifest_debt_not_hidden": _score_probe(
            manifest_tier["returncode"] == 0 and tier_json.get("status") == "warn" and int(tier_json.get("warning_count", 0)) > 0,
            "Remaining manifest-tier debt is visible as WARN rather than silently marketed as solved.",
        ),
        "benchmark_plan_available": _score_probe(
            benchmark_plan["returncode"] == 0 and "tasks × 2 modes" in benchmark_plan.get("stdout_tail", ""),
            "Existing so-vs-vanilla benchmark plan is runnable in no-provider dry-run mode.",
        ),
    }
    pass_count = sum(1 for item in probes.values() if item["status"] == "pass")
    status_value = "pass" if pass_count == len(probes) else "fail"
    report = {
        "schema_version": "cos-vs-ai-slop-two-repo-smoke.v1",
        "generated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "status": status_value,
        "mode": "non-provider-two-repo-substrate-smoke",
        "harness": harness,
        "temp_root": str(tmp) if keep else "removed",
        "repo_roles": {
            "vanilla": "native harness literacy baseline fixture",
            "cos": "same fixture plus projected COS substrate",
        },
        "limitations": [
            "Does not execute live model tasks.",
            "Does not prove time-to-merge, defect-rate, or cognitive-load wins.",
            "Only proves the local substrate needed before running the A/B/C falsification benchmark.",
        ],
        "digests": {
            "vanilla_before": vanilla_before,
            "vanilla_after": vanilla_after,
            "cos_before": cos_before,
            "cos_after": cos_after,
        },
        "install_meta": {
            "harness": install_meta.get("harness"),
            "hooks_installed": install_meta.get("hooks_installed"),
            "rules_installed": install_meta.get("rules_installed"),
            "skills_installed": install_meta.get("skills_installed"),
        },
        "manifest_tier_summary": {
            "status": tier_json.get("status"),
            "primitive_count": tier_json.get("primitive_count"),
            "finding_count": tier_json.get("finding_count"),
            "warning_count": tier_json.get("warning_count"),
            "counts_by_category": tier_json.get("counts_by_category"),
        },
        "probes": probes,
        "commands": {
            "install": install,
            "status": _compact_command(status),
            "public_claim_gate": _compact_command(claim_gate),
            "manifest_tier": _compact_command(manifest_tier),
            "benchmark_plan": _compact_command(benchmark_plan),
        },
    }
    if keep:
        tmp_ctx.cleanup = lambda: None  # type: ignore[method-assign]
    tmp_ctx.cleanup()
    return report


def _read_json_from_output(text: str) -> dict[str, Any]:
    try:
        return json.loads(text)
    except Exception:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start : end + 1])
            except Exception as exc:
                return {"_error": str(exc)}
        return {"_error": "no json object found"}


def _compact_command(result: dict[str, Any]) -> dict[str, Any]:
    return {
        "cmd": result["cmd"],
        "returncode": result["returncode"],
        "stdout_tail": result.get("stdout_tail", "")[-500:],
        "stderr_tail": result.get("stderr_tail", "")[-500:],
    }


def render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# COS vs AI Slop Two-Repo Smoke — Latest",
        "",
        f"Generated: `{report['generated_at']}`",
        f"Status: `{report['status']}`",
        f"Mode: `{report['mode']}`",
        f"Harness: `{report['harness']}`",
        "",
        "## What this proves",
        "",
        "This smoke creates two equivalent fixture repositories: a vanilla baseline and a COS-projected repo. It proves local substrate, evidence gates, and visible debt handling before any live model benchmark is run.",
        "",
        "## Probe results",
        "",
        "| Probe | Status | Rationale |",
        "|---|---|---|",
    ]
    for name, row in report["probes"].items():
        lines.append(f"| `{name}` | `{row['status']}` | {row['rationale']} |")
    summary = report.get("manifest_tier_summary", {})
    lines += [
        "",
        "## Manifest-tier debt visibility",
        "",
        f"- status: `{summary.get('status')}`",
        f"- primitives: `{summary.get('primitive_count')}`",
        f"- findings: `{summary.get('finding_count')}`",
        f"- warnings: `{summary.get('warning_count')}`",
        "",
        "## Limitations",
        "",
    ]
    for item in report.get("limitations", []):
        lines.append(f"- {item}")
    lines += [
        "",
        "## Next benchmark step",
        "",
        "Run the manual A/B/C falsification benchmark for at least three task classes. This smoke only proves that the two-repo substrate and honesty gates are ready.",
        "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-dir", type=Path, default=ROOT)
    parser.add_argument("--harness", default="codex", choices=["codex", "claude"])
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--keep", action="store_true")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="Run without updating latest report files.")
    mode.add_argument("--write-report", action="store_true", help="Update tracked latest JSON/Markdown report files.")
    args = parser.parse_args(argv)
    report = build_report(args.project_dir, args.harness, args.keep)
    if args.write_report:
        DEFAULT_JSON.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        DEFAULT_MD.write_text(render_markdown(report) + "\n", encoding="utf-8")
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print(f"cos-vs-ai-slop-two-repo-smoke: {report['status']} probes={len(report['probes'])}")
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
