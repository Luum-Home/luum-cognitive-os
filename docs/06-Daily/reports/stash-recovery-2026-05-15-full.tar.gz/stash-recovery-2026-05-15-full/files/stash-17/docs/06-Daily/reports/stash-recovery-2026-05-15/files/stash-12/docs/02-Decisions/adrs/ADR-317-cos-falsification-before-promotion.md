---
adr: 317
title: COS Falsification Before Promotion
status: accepted
implementation_status: implemented
date: '2026-05-15'
extends:
  - ADR-316
  - ADR-314
  - ADR-252
supersedes: []
superseded_by: null
implementation_files:
  - docs/08-References/business/cos-vs-ai-slop-falsification.md
  - docs/09-Quality/manual-tests/cos-vs-ai-slop-falsification.md
  - docs/06-Daily/reports/manifest-tier-warning-backlog-2026-05-15.md
  - scripts/primitive_scope_classifier.py
  - tests/unit/test_primitive_scope_classifier.py
tier: core
tags:
  - product-boundary
  - falsification
  - agentic-literacy
  - evidence
  - anti-slop
classification_basis: accepted operator directive that COS must be tested against harness-literate native agent workflows and demoted when it adds ceremony without measurable benefit.
verification:
  level: medium
  commands:
    - scripts/cos-manifest-tier-claim-audit --json
    - .venv/bin/python -m pytest tests/contracts/test_product_zones.py tests/contracts/test_adr_status_taxonomy.py tests/unit/test_primitive_scope_classifier.py -q
  proves:
    - manifest-tier claims stay visible instead of being marketed as universal coverage
    - ADR metadata remains parseable and indexed
    - lab distribution stays orthogonal to semantic SCOPE
---

# ADR-317 — COS Falsification Before Promotion

## Status

Accepted and implemented as product-governance doctrine — 2026-05-15.

<!-- SCOPE: both -->

## Context

After ADR-316 established that Cognitive OS must not replace agentic literacy, the operator asked how to know whether the SO reinvents agentic work or is AI slop.

The answer must be falsifiable. A larger set of hooks, skills, rules, ADRs, and manifests is not evidence by itself. Cognitive OS must be compared against developers who can already operate native coding-agent harnesses directly.

## Decision

Cognitive OS primitives and profiles must be promoted only when they improve measurable outcomes over a harness-literate baseline, or when they preserve a clearly documented safety/recovery property that the baseline lacks.

The canonical comparison is:

1. Group A: native harness literacy only.
2. Group B: minimal COS profile.
3. Group C: full COS profile.

The winning scope determines the product claim. If Group B wins, the default product is minimal COS plus agentic literacy. If Group C wins only for specific task classes, the broader mesh remains scoped to those task classes. If Group A wins, COS must demote the related primitives or keep them in lab.

## Promotion Rule

A primitive cannot be default-core merely because it is reusable. Default-core requires at least one of:

- runtime-safety blocker proof;
- quality-adjusted benchmark win;
- measurable context-recovery improvement;
- documented safety property that native harness use commonly misses;
- explicit pedagogical value that improves harness literacy rather than hiding it.

Otherwise the primitive belongs in `lab`, `maintainer`, `team`, or another non-default profile until evidence improves. A `lab` distribution is a product-promotion tier, not semantic proof that the primitive is OS-only; shared-surface primitives can remain `both` while staying opt-in.

## Consequences

### Positive

- Product claims become harder to inflate.
- The default profile stays small unless the broader mesh proves its value.
- Developers keep learning Codex, Claude Code, OpenCode, Goose, shell, git, tests, permissions, and SDD.
- Manifest demotions become a product-quality action, not a regression.

### Negative / Trade-offs

- Some impressive-sounding automation remains lab/advisory until benchmarked.
- Full-mesh promotion slows down because it needs task-class evidence.
- Manual benchmark work is required before some claims can become public-facing.

## Alternatives Rejected

| Alternative | Why rejected |
|---|---|
| Promote the full SO because it is internally coherent | Internal coherence can still be AI slop if it fails against native harness workflows. |
| Keep all reusable primitives in core | Reusability is not proof of default-product value. |
| Use docs volume or primitive counts as success metrics | Counts reward taxonomy expansion rather than engineering outcomes. |
| Treat harness literacy and COS as competing products | The accepted boundary is that COS must reinforce harness literacy. |

## Verification

```bash
scripts/cos-manifest-tier-claim-audit --json
.venv/bin/python -m pytest tests/contracts/test_product_zones.py tests/contracts/test_adr_status_taxonomy.py tests/unit/test_primitive_scope_classifier.py -q
```

The first command keeps distribution overclaims visible. The second keeps ADR/product-zone governance parseable while this doctrine is linked into the repo.

## Related

- [ADR-316 — Agentic Literacy Before OS Abstraction](ADR-316-agentic-literacy-before-os-abstraction.md)
- [Cognitive OS vs AI Slop Falsification Protocol](../../08-References/business/cos-vs-ai-slop-falsification.md)
- [COS vs AI Slop Falsification Manual Test](../../09-Quality/manual-tests/cos-vs-ai-slop-falsification.md)
