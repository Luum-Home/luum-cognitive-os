# Cognitive OS vs AI Slop Falsification Protocol

## Purpose

Cognitive OS must prove it changes agent-assisted development outcomes, not merely produce a larger taxonomy of hooks, skills, rules, ADRs, and manifests.

This document turns the strategic question into a falsifiable product test:

> Does Cognitive OS improve work by developers who understand modern coding-agent harnesses, or does it add ceremony that hides the underlying tools?

## Non-Negotiable Boundary

Cognitive OS is valuable only if it reinforces agentic literacy. It must not replace a developer's ability to operate Codex, Claude Code, OpenCode, Goose, shell, git, tests, permissions, prompt-injection defenses, and SDD reasoning directly.

Reference decision: [ADR-316 — Agentic Literacy Before OS Abstraction](../../02-Decisions/adrs/ADR-316-agentic-literacy-before-os-abstraction.md).

## Experiment Design

Run the same realistic engineering tasks through three operating modes.

| Group | Operating mode | What it tests |
|---|---|---|
| A | Harness-literate baseline | Developers use native Codex/Claude/OpenCode/Goose plus shell, git, tests, PI defense, and SDD without COS ceremony. |
| B | Minimal COS | Same developers use a small COS slice: memory, claim gates, minimal hooks, SDD, and a few proven skills. |
| C | Full COS mesh | Same developers use the broad COS profile with the full available governance surface. |

The question is not whether COS can produce more artifacts. The question is whether it improves measurable outcomes over group A without imposing more cognitive load than it removes.

## Task Selection

Each benchmark task must be realistic enough to expose agent failure modes:

1. a bug fix with failing tests and an ambiguous root cause;
2. a feature with cross-file changes and acceptance criteria;
3. a security-sensitive change involving tool permissions, secrets, or untrusted input;
4. a documentation/claim update where stale or overbroad language must be corrected;
5. a recovery task after interrupted context or partially completed work.

Synthetic toy tasks are not sufficient because they reward ceremony-light workflows and do not test memory, safety, or recovery value.

## Metrics

| Metric | Definition | Slop signal |
|---|---|---|
| Time-to-merge | Wall time from task start to passing validation. | COS groups are slower without quality gain. |
| Defect rate | Bugs, broken tests, regressions, or review findings after completion. | COS creates artifacts but misses defects. |
| Unsafe actions | Blocked or unblocked dangerous operations: secrets, destructive git, untrusted input, uncontrolled tool use. | COS fails to prevent risky actions or hides why they are risky. |
| Agent loops | Repeated retries, circular debugging, or stuck behavior. | COS adds routing/context overhead that increases loops. |
| Context recovery | Ability to resume after interruption with correct next action. | COS memory is verbose but not actionable. |
| Cognitive load | Reviewer rating of whether the operator understands what happened. | COS hides the harness behind opaque ritual. |
| Evidence quality | Presence of tests, commands, traces, receipts, and uncertainty statements. | Claims are made without proof. |
| Harness literacy | Whether the developer can explain the native harness/tool surface used. | COS users cannot operate or debug outside COS. |

## Verdict Rules

| Outcome | Interpretation | Product action |
|---|---|---|
| Group A wins | COS is likely AI slop or premature abstraction for that task class. | Freeze promotion; teach harness literacy first; demote related primitives to lab. |
| Group B wins | The product is minimal COS plus agentic literacy. | Keep default profile small; promote only proven minimal primitives. |
| Group C wins | The broader SO is justified for that task class. | Promote the winning primitives with evidence and profile-specific docs. |
| No clear winner | Evidence is insufficient. | Keep claims advisory and rerun with better tasks or measurement. |

A single win does not justify universal claims. Results must stay scoped by task class, harness, profile, and date.

## AI Slop Tripwires

A primitive, feature, or claim is slop-risky when it has any of these properties:

- it creates more taxonomy than execution evidence;
- it says universal, autonomous, self-improving, production-ready, or multi-IDE without proof level;
- it hides native harness behavior that developers must understand;
- it cannot fail in a visible way;
- it adds cognitive load to simple tasks without reducing measurable risk;
- it is marked `core` or `team` while only being advisory/reusable;
- it treats `lab` as semantic OS-only proof instead of a product-promotion tier;
- it depends on maintainer intuition rather than durable rationale.

## Current Attack Path

The first attack path is already underway:

1. Public claims were corrected in [Promise Compliance Audit — 2026-05-15](promise-compliance-audit-2026-05-15.md).
2. The agentic literacy boundary was accepted in ADR-316.
3. Manifest-tier warnings are being reduced by demoting advisory primitives that lack runtime-safety proof; see [Manifest Tier Warning Backlog — 2026-05-15](../../06-Daily/reports/manifest-tier-warning-backlog-2026-05-15.md).
4. The next step is to run the manual falsification drill in [COS vs AI Slop Falsification Manual Test](../../09-Quality/manual-tests/cos-vs-ai-slop-falsification.md).

## Acceptance Criteria

Cognitive OS can claim it improves agentic development only when:

1. at least one benchmark task class shows group B or C beating group A on quality-adjusted outcome;
2. the winning profile lists the exact primitives used;
3. each promoted primitive has evidence or a demotion rationale;
4. the docs preserve proof-level vocabulary instead of collapsing everything into support claims;
5. the operator can still explain the underlying native harness workflow.
