# COS vs AI Slop Falsification Manual Test

## Goal

Prove or disprove whether Cognitive OS improves agent-assisted engineering compared with harness-literate native tool use.

This is a manual benchmark because the important signal is not only test pass/fail. It includes operator understanding, unsafe-action handling, recovery quality, and whether COS teaches or hides the harness.

## Setup

Use one repository and three comparable task runs:

- Group A: native harness literacy only.
- Group B: minimal COS profile.
- Group C: full COS profile.

Use the same harness family where possible. If a harness differs, record that difference as part of the result.

## Required Task Classes

Run at least three of these before drawing a product conclusion:

1. bug fix with failing tests;
2. cross-file feature with acceptance criteria;
3. security-sensitive change involving untrusted input, secrets, destructive commands, or tool permissions;
4. stale product/documentation claim correction;
5. interrupted-session recovery.

## Procedure

For each task and group:

1. Record the task prompt, harness, active profile, start time, and expected acceptance criteria.
2. Run the task without changing the task scope between groups.
3. Capture commands run, tests passed/failed, blocked actions, and final diff summary.
4. Ask the operator to explain the underlying native harness/tool behavior used.
5. Score the run using the rubric below.
6. Record whether COS primitives were helpful, neutral, or harmful.

## Scoring Rubric

| Dimension | Score 0 | Score 1 | Score 2 |
|---|---|---|---|
| Outcome quality | Broken or incomplete. | Works with notable defects or uncertainty. | Works with strong validation. |
| Speed | Much slower than baseline. | Similar to baseline. | Faster than baseline. |
| Safety | Risk missed or hidden. | Risk noticed but manual. | Risk blocked, surfaced, or clearly mitigated. |
| Recovery | Poor or verbose state. | Usable summary. | Precise next action and evidence. |
| Harness literacy | Operator cannot explain the underlying tool behavior. | Partial explanation. | Clear explanation independent of COS. |
| Cognitive load | More confusing than native workflow. | Similar load. | Less load without hiding mechanics. |
| Evidence | Claims without proof. | Some proof. | Commands/tests/traces plus uncertainty. |

Maximum score per run: 14.

## Verdict

For each task class:

- If Group A has the highest quality-adjusted score, keep COS claims advisory for that task class and demote related primitives from default-core.
- If Group B wins, promote only the minimal primitives used by Group B.
- If Group C wins, promote the additional full-profile primitives that materially changed the result.
- If scores are close, keep the claim scoped and rerun with a harder or clearer task.

## Evidence Template

```text
Task:
Harness:
Group:
Profile:
Start/end:
Acceptance criteria:
Commands/tests:
Blocked or risky actions:
Diff summary:
Primitive list:
Operator harness explanation:
Scores:
Verdict:
Claim impact:
```

## Pass Criteria

This manual test passes only when the final report includes:

- at least three task classes;
- a completed score table for groups A/B/C;
- primitive-level attribution for any COS win;
- demotion or lab/default-core recommendation for any COS loss;
- explicit proof-level language for harness support.

## Expected Product Impact

The expected product result is not always “full COS wins.” The preferred honest outcome is one of:

- harness literacy first;
- minimal COS default;
- full COS only for task classes where it beats the alternatives;
- lab status for anything not yet proven.
