#!/usr/bin/env python3
# SCOPE: os-only
"""Single boring-reliability dashboard for Cognitive OS."""
from __future__ import annotations

import argparse
import json
import sys
import subprocess
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import cos_adoption_profile
import cos_default_visible_reducer
import cos_false_positive_ledger
import cos_preamble_budget
import cos_wip_safety_score
import runtime_hook_reality
import silent_failure_audit
import session_start_budget
import cos_demotion_loop_audit
import cos_manifest_tier_claim_audit



def dispatch_metrics_evidence(root: Path) -> dict[str, Any]:
    dispatch_path = root / ".cognitive-os" / "metrics" / "llm-dispatch.jsonl"
    history_path = root / ".cognitive-os" / "metrics" / "task-history.jsonl"
    dispatch_bytes = dispatch_path.stat().st_size if dispatch_path.exists() else 0
    history_bytes = history_path.stat().st_size if history_path.exists() else 0
    status = "pass" if dispatch_bytes > 0 and history_bytes > 0 else "warn"
    return {
        "status": status,
        "llm_dispatch_bytes": dispatch_bytes,
        "task_history_bytes": history_bytes,
        "repair_command": "scripts/cos-dispatch-smoke --json",
    }

def readiness_summary(root: Path) -> dict[str, Any]:
    proc = subprocess.run(["python3", "scripts/cos_architecture_readiness.py", "--json"], cwd=root, text=True, capture_output=True, check=False)
    try:
        report = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return {"status": "fail", "error": proc.stderr[-1000:]}
    return {"status": report.get("status"), "pass": report.get("pass_count"), "warn": report.get("warn_count"), "fail": report.get("fail_count"), "returncode": proc.returncode}


def build_dashboard(profile: str = "core", root: Path = REPO_ROOT) -> dict[str, Any]:
    runtime = runtime_hook_reality.build_report(
        project_root=root,
        settings_path=root / ".claude" / "settings.json",
        manifest_path=root / "manifests" / "primitive-lifecycle.yaml",
    )
    adoption = cos_adoption_profile.build_profile(profile)
    preamble = cos_preamble_budget.build_budget(profile, root)
    reducer = cos_default_visible_reducer.build_recommendations()
    false_positive = cos_false_positive_ledger.build_report(root / ".cognitive-os" / "metrics")
    wip = cos_wip_safety_score.build_score(root)
    silent = silent_failure_audit.build_report(root, root / "hooks", root / "manifests" / "silent-failure-allowlist.yaml")
    session_budget = session_start_budget.build_report(profile, root)
    dispatch_evidence = dispatch_metrics_evidence(root)
    manifest_tier_claims = cos_manifest_tier_claim_audit.build_report(root / "manifests" / "primitive-lifecycle.yaml")
    demotion_loop = cos_demotion_loop_audit.build_report(root / "manifests" / "primitive-lifecycle.yaml")
    readiness = readiness_summary(root)
    status_items = [runtime["summary"]["status"], adoption["status"], preamble["status"], wip["status"], silent["status"], session_budget["status"], dispatch_evidence["status"], manifest_tier_claims["status"], demotion_loop["status"], readiness["status"]]
    overall = "fail" if "fail" in status_items else ("warn" if "warn" in status_items else "pass")
    return {
        "status": overall,
        "profile": profile,
        "runtime_reality": runtime["summary"],
        "adoption_profile": {k: adoption[k] for k in ("status", "primitive_count", "hook_count", "default_visible_count", "blocking_count")},
        "preamble_budget": preamble,
        "default_visible_reducer": {"status": reducer["status"], "recommendation_count": reducer["recommendation_count"], "recommendations": reducer["recommendations"][:10]},
        "false_positive_ledger": false_positive,
        "wip_safety": wip,
        "session_start_budget": {
            "status": session_budget["status"],
            "profile": session_budget["profile"],
            "session_start_hook_count": session_budget["session_start_hook_count"],
            "projection_source": session_budget.get("projection_source"),
            "active_session_start_hook_count": session_budget.get("active_session_start_hook_count"),
            "active_projection_matches_profile": session_budget.get("active_projection_matches_profile"),
            "counts_by_tier": session_budget["counts_by_tier"],
            "budget": session_budget["budget"],
            "findings": session_budget["findings"],
        },
        "silent_failure_audit": {
            "status": silent["status"],
            "file_count": silent["file_count"],
            "occurrence_count": silent["occurrence_count"],
            "fail_count": silent["fail_count"],
            "warn_count": silent["warn_count"],
            "counts_by_degradation_class": silent.get("counts_by_degradation_class", {}),
            "legacy_audited_count": silent.get("legacy_audited_count", 0),
        },
        "dispatch_metrics_evidence": dispatch_evidence,
        "manifest_tier_claims": {
            "status": manifest_tier_claims["status"],
            "finding_count": manifest_tier_claims["finding_count"],
            "counts_by_category": manifest_tier_claims["counts_by_category"],
            "candidate_second_demote_count": manifest_tier_claims["candidate_second_demote_count"],
            "candidate_second_demotes": manifest_tier_claims["candidate_second_demotes"][:10],
        },
        "demotion_loop": {
            "status": demotion_loop["status"],
            "demotion_count": demotion_loop["demotion_count"],
            "roi_signed_demotion_count": demotion_loop["roi_signed_demotion_count"],
            "findings": demotion_loop["findings"],
            "policy": demotion_loop["policy"],
        },
        "readiness": readiness,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=["core", "team", "maintainer", "lab"], default="core")
    parser.add_argument("--json", action="store_true", help="accepted for CLI consistency; output is always JSON")
    parser.add_argument("--fail-on-warn", action="store_true", help="exit non-zero on warn as well as fail")
    args = parser.parse_args(argv)
    report = build_dashboard(args.profile)
    print(json.dumps(report, indent=2, sort_keys=True))
    if report["status"] == "fail":
        return 1
    if args.fail_on_warn and report["status"] == "warn":
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
